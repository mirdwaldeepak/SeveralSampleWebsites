﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISAM5338_Assignment_01
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Hardware> hardwares = Hardware.GetSampleDataSet();
            var query1 = from h in hardwares
                         orderby h._Part_Number
                         select new
                         {
                             Id = h._Part_Number,
                             Item = h._Description,
                             Quantity = h._Quantity,
                             Price_Each = h._Part_Number
                         };

            GridView1.DataSource = query1;
            GridView1.DataBind();

            Response.Write("<br/>");
            Response.Write("<br/>");

            var query2 = from i in hardwares
                         let Worth = i._Quantity * i._Each_Price
                         select new
                         {
                             Id = i._Part_Number,
                             Item = i._Description,
                             worth = Worth
                         };

            GridView2.DataSource = query2;
            GridView2.DataBind();


            var query3 = hardwares.Sum(h => h._Quantity * h._Each_Price);
            Label1.Text = query3.ToString();


        }
    }
}