﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISAM5338_Assignment_01
{
    public partial class Part2_customer_invoice : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Customer> customers = Customer.GetData();
            List<Invoice> invoices = Invoice.getinvoicedata();

            var query = customers.Select(h => h);

            GridView1.DataSource = query;
            GridView1.DataBind();

            var query1 = invoices.Select(a => a);

            GridView2.DataSource = query1;
            GridView2.DataBind();

            var query2 = from c in customers
                         join i in invoices on c.Id equals i.Customer_id
                         select new
                         {
                             customer_name = c.First_name + " " + c.Last_name,
                             zip_code = c.Zip_code,
                             date_of_sale = i.Purchase_date,
                             Purchase_amount = i.Purchase_amount
                         };
            GridView3.DataSource = query2;
            GridView3.DataBind();
        }
    }
}