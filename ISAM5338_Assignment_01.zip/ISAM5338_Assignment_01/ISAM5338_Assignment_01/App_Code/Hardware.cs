﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ISAM5338_Assignment_01
{
    public class Hardware
    {
        public int _Part_Number { get; set; }
        public string _Description { get; set; }
        public int _Quantity { get; set; }
        public double _Each_Price { get; set; }

        public Hardware()
        {

        }

        public Hardware(int part_number, string description, int quantity, double each_price)
        {
            this._Part_Number = part_number;
            this._Description = description;
            this._Quantity = quantity;
            this._Each_Price = each_price;
        }
        public static List<Hardware> GetSampleDataSet()
        {
            List<Hardware> hardwares = new List<Hardware>();


            hardwares.Add(new Hardware(2, "Hammer, regular", 23, 16.99));
            hardwares.Add(new Hardware(3, "Hand Saw", 423, 5.99));
            hardwares.Add(new Hardware(23, "Nails", 30, 2.99));
            hardwares.Add(new Hardware(11, "Screwdriver", 11, 1.99));
            hardwares.Add(new Hardware(21, "Wrench, 3/8\"", 12, 3.49));
            hardwares.Add(new Hardware(11, "Wrench, 1/2\"", 98, 3.49));
            hardwares.Add(new Hardware(13, "Socket Set", 32, 29.99));
            hardwares.Add(new Hardware(23, "Punch", 12, 4.99));
            hardwares.Add(new Hardware(55, "JigSaw", 11, 39.99));
            hardwares.Add(new Hardware(108, "Hammer, Sledge", 44, 26.99));
            hardwares.Add(new Hardware(40, "Saw, Coping", 58, 8.49));
            return hardwares;
        }
    }
}