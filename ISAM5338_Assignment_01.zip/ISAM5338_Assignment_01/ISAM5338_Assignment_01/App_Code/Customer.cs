﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ISAM5338_Assignment_01
{
    public class Customer
    {
        public int Id { get; set; }
        public string First_name { get; set; }
        public string Last_name { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int Zip_code { get; set; }
        public string Phone_no { get; set; }

        public Customer()
        {

        }

        public Customer(int _id, string _firstname, string _lastname, string _address, string _city, string _state, int _zipcode, string phone_no)
        {
            this.Id = _id;
            this.First_name = _firstname;
            this.Last_name = _lastname;
            this.Address = _address;
            this.City = _city;
            this.State = _state;
            this.Zip_code = _zipcode;
            this.Phone_no = phone_no;
        }

        public static List<Customer> GetData()
        {
            List<Customer> customers = new List<Customer>();
            customers.Add(new Customer(1, "Art", "Venere", "8 W Cerritos Ave #54", "Bridgeport", "NJ", 08014, "856-636-8749"));
            customers.Add(new Customer(2, "Lenna", "Paprocki639", "Main St", "Anchorage", "AK", 99501, "907-385-4412"));
            customers.Add(new Customer(3, "Donette", "Foller", "34 Center St", "Hamilton", "OH", 45011, "513-570-1893"));
            customers.Add(new Customer(4, "Simona", "Morasca", "3 Mcauley Dr", "Ashland", "OH", 44805, "419-503-2484"));
            customers.Add(new Customer(5, "Mitsue", "Tollner", "7 Eads St", "Chicago", "IL", 60632, "773-573-6914"));
            customers.Add(new Customer(6, "Leota", "Dilliard", "7 W Jackson Blvd", "San Jose", "CA", 95111, "408-752-3500"));
            customers.Add(new Customer(7, "Sage", "Wieser", "5 Boston Ave #88", "Sioux Falls", "SD", 57105, "605-414-2147"));
            customers.Add(new Customer(8, "Kris", "Marrier", "228 Runamuck Pl #2808", "Baltimore", "MD", 21224, "410-655-8723"));

            return customers;
        }
    }
}