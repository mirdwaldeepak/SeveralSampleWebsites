﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ISAM5338_Assignment_01
{
    public class Invoice
    {
        public int Id { get; set; }
        public int Customer_id { get; set; }
        public DateTime Purchase_date { get; set; }
        public double Purchase_amount { get; set; }

        public Invoice()
        {

        }

        public Invoice(int _id, int customer_id, DateTime date, double purchase_amount)
        {
            this.Id = _id;
            this.Customer_id = customer_id;
            this.Purchase_date = date;
            this.Purchase_amount = purchase_amount;
        }   

        public static List<Invoice> getinvoicedata()
        {
            List<Invoice> invoices = new List<Invoice>();
            invoices.Add(new Invoice(1, 5, new DateTime(2015,2,12), 300));
            invoices.Add(new Invoice(2, 2, new DateTime(2016, 8, 1), 250));
            invoices.Add(new Invoice(3, 3, new DateTime(2006, 4, 2), 235.6));
            invoices.Add(new Invoice(4, 5, new DateTime(2011, 1, 12), 264.1));
            invoices.Add(new Invoice(5, 2, new DateTime(2008, 1, 8), 112));
            invoices.Add(new Invoice(6, 1, new DateTime(2009, 3, 9), 119.7));
            invoices.Add(new Invoice(7, 8, new DateTime(2010, 7, 2), 289.25));

            return invoices;
        }
    }
}